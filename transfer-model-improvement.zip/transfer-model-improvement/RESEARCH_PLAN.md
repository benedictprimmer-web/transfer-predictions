# RESEARCH PLAN — Phase 1 (establish before building)

*Everything here is a query against the warehouse, not a literature review. Output: `MODEL_01_research.md`
with the numbers, a go/no-go, and any target/feature decision you had to make. Do not write model code
until this is done.*

## R1 — Define and measure the target

**Target: forward 2-year Δlog(market value), residualized on an age(+league) baseline.**

Why residualized: the review proved that an age-blind talent-minus-price gap is dominated by cheap
veterans whose decline the market correctly prices (pooled Spearman −0.114 was a Simpson artifact of age
composition; within every age band the raw gap carried near-zero signal, rho 0.006–0.066). If the target
is raw MV growth, the model relearns "being young." Residualizing the target on age (and league) forces it
to mean "**repriced beyond what age alone predicts**" — which is the actual edge.

Steps:
1. From `valuations` (507,815 rows, `player_id`, `date`, `market_value_in_eur`), build per-player MV
   observations. Confirm the review's count: **445,671 usable rows** with ≥2 prior points. Report your number.
2. For each player-season anchor, compute Δlog(MV) from anchor to anchor+2y. Fit a baseline
   `log(MV) ~ age + age² + league` (or a smoother) and take the **residual** as the target.
3. Coverage check: how many player-seasons have both a price-blind feature vector (R2) **and** a
   future-dated target? This intersection is your trainable set. Report it by season and position.
4. Confirm strict future-dating: the target window must start **after** the feature season ends. No overlap.

## R2 — Inventory the price-blind feature panel

Build one row per player-season. **Price-blind features only** (no MV/wage/fee, ever). For each, report
coverage (% of the trainable set) and decide keep / impute / drop, recording the decision:

| Feature | Source | Notes |
|---|---|---|
| Usage share | `impact/usage.py::usage_efficiency` | player's share of team terminal actions; penalties/OGs already excluded |
| npxG efficiency | same | (xG+xAG) per terminal action |
| Own xG geometry | `impact/xg_model.py` | distance/angle/header/open-play; a baseline, but price-blind |
| Minutes-at-level | `fbref_perf` (2024-26 xG present, see traps) + Understat | normalize per-90; **fbref_perf is fresher than the "frozen ≤2023" framing suggests** |
| WOWY (pooled) | `impact/wowy.py` | team xGD on/off; thin, needs lineups — pooled per-player-season only |
| Turnovers | `fbref_snapshot` / `fbref_niche` | dispossessed + miscontrols, 2018+ |
| Defensive layer | `fbref_defense` / `ingest/defensive_value.py` | **unitless today** — usable as a feature, not yet as a price |
| Aging position | `impact/aging.py::age_multiplier(age,pos)` | value_p90 curve; a *feature*, and the target's baseline |
| Availability / durability | `injuries` (34,561 rows) | `availability`, `injury_prone` |
| xT / VAEP | **not built yet** — StatsBomb events on disk | the optional enrichment track; scores defenders/deep mids |

Position balance matters: shot-based signal covers forwards and mids; **defenders are thin and keepers are
absent** (the review found 0 scoreable GKs, 215 defenders with ≥100 career shots vs 680 attackers). Decide
explicitly how the model treats positions it can barely see — do not silently score them from noise.

## R3 — Leakage audit (this is where projects die)

- Prove no feature at season S encodes information from ≥ S (the review confirmed the project's own
  `transfer_performance_link_safe` enforces `perf_season < transfer_season` on all 91,081 rows — mirror that
  discipline).
- Prove the target is strictly future-dated relative to features.
- Confirm you are **not** re-introducing the leak just fixed in `money/fees.py`: random K-fold on
  time-ordered data with `season` as a feature. Your CV is expanding-window walk-forward, full stop.
- Contracts are **current-state, not point-in-time** (98% of transfers would see a post-dated expiry) —
  do not use `contracts.contract_expiration_date` as a feature without freezing it as-of the season.

## R4 — Understand the ceiling (so you pick the right target)

`validate/stage4.py` established usage→WOWY is r=+0.077 [+0.030,+0.125] — real but <1% variance. That is
the ceiling for predicting **per-deal team impact**, which is why that is **not** your target. Forward
MV-growth is denser (445k rows) and better-posed. Confirm you understand this before Phase 2; state it in
`MODEL_01_research.md`. If you believe a better target exists, argue it with numbers — but the default is
forward residualized Δlog(MV).

## Go / no-go
Proceed to build only if: (a) the trainable intersection is ≥ ~5,000 player-seasons, (b) the leakage audit
is clean, (c) at least 4 price-blind features clear 50% coverage. Otherwise, report the blocker honestly.
