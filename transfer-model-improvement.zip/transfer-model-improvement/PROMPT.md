# PROMPT — Build the price-blind talent model (GPT 5.6)

*Paste this into a GPT 5.6 coding session opened in `~/Transfer Predictions`. The other files in this
bundle are your reference material; this is your brief. Use `python3` (plain `python` is not on PATH).*

---

You are a skeptical ML engineer improving a football-transfer valuation system. There is **no trained
model** in it today — only a hand-built scoring chain. You will build **one** new model: a **price-blind
talent model** that scores a player's on-pitch quality independent of his market value, wage, and fee.
The commercial thesis it serves:

> **Edge = players whose on-pitch quality ranks far above what their price implies.** Market value and
> wages are *parallel context*, never the target. The target is the quality signal itself, and the
> edge lives in the gap between quality and price.

A prior verified review proved the raw material exists (talent diverges from price with real signal) but
that the current formulation does **not** predict repricing. Your model must beat a set of falsifiable
gates or fail them honestly. **You may never loosen a gate to make a result look good.**

## Non-negotiable constraints

1. **Price-blindness is structural, not aspirational.** The feature matrix must contain **zero** columns
   derived from market value, wage, or fee. The scaffold asserts this at fit time — keep the assertion.
   Price data enters only as the *target* (forward MV growth) and as the *benchmark* you measure the gap
   against — never as an input feature.
2. **Query, don't crawl.** Read the warehouse via `from ingest import warehouse; con = warehouse.connect()`
   (read-only DuckDB, 15 tables, join on `tm_player_id`). Never open a raw `.rds/.pkl/.parquet/.json` blob
   to "understand" the data — `context/DATA_MAP.md` already maps it.
3. **Out-of-time everything.** Splits are expanding-window by season. Random K-fold on this time-ordered
   data is the exact leak this project just fixed in `money/fees.py` — do not reintroduce it anywhere.
4. **A green `_check()` is not a correct result.** Gate on out-of-time backtests and the sanity cases.
5. **Reuse before building.** `impact/usage.py::usage_efficiency`, `impact/aging.py::age_multiplier`,
   `impact/wowy.py`, `validate/npv_backtest.py` (correct era splits), `validate/stage4.py` already exist.
   Do not reinvent them.

## Phases (execute in order; do not wait for permission between them)

### Phase 0 — Orient (cheap)
Read `context/` and `RESEARCH_PLAN.md`. Confirm the warehouse connects and the row counts in
`context/DATA_MAP.md` still hold (spot-check 3). Write `MODEL_00_scope.md`: your target definition, your
feature list, your split scheme, and the four gates — one page, your plan of record.

### Phase 1 — Research the target and features (see `RESEARCH_PLAN.md`)
Establish, with real queries, before writing model code:
- The **target**: forward 2-year Δlog(market value), **residualized on an age(+league) baseline** so the
  signal is "repriced *beyond* what age alone predicts," not "is young." Quantify coverage (the review
  found 445,671 usable MV rows with ≥2 prior points; confirm).
- The **feature panel**: one row per player-season, price-blind features only (see `BUILD_PLAN.md` §2).
  Report coverage and missingness per feature; decide imputation vs drop per feature, and record it.
- The **leakage audit**: prove no feature at season S encodes anything from ≥ S. Prove the target is
  strictly future-dated. Re-use the discipline in `validate/npv_backtest.py`.
- The **ceiling**: `validate/stage4.py` shows usage→WOWY r=+0.077. That rules out per-deal team-impact as
  a target — confirm you understand why forward-MV-growth is the well-posed target instead.
Return `MODEL_01_research.md`: target rows, feature coverage table, leakage-audit result, go/no-go.

### Phase 2 — Build the model (see `BUILD_PLAN.md`)
- Copy `scaffold/impact_talent.py` → `impact/talent.py` and implement it. **One pooled model**, not
  per-position (perf coverage is too thin to split — see `context/DATA_MAP.md`). Gradient-boosted trees
  (the repo already uses HistGBR) with expanding-window walk-forward, every prediction out-of-time.
- Emit a per-player-season **talent score** with an uncertainty band, plus its **percentile rank** within
  season×position. Persist to `data/money/talent_scores.csv` via a `ship()` function (`data/` is now
  tracked in git, not gitignored — see `context/KNOWN_TRAPS.md`).
- Keep the `_check()` offline synthetic test in the scaffold passing at every step.

### Phase 3 — Gate it (see `GATES.md`; copy `scaffold/validate_talent_gate.py` → `validate/talent_gate.py`)
Run all four, report each pass/fail with numbers and bands:
1. **Beats an age-only baseline out-of-time** — a talent model that is secretly an age curve is worthless.
2. **Haaland-underpay / Antony-overpay** sanity holds when the talent score feeds the price gap.
3. **Decile forward-MV cohort monotonicity** — higher talent-minus-price decile → higher realized growth.
4. **Gem screen beats base rate** — the reformulated screen (within-position, age-residual baseline,
   realized-fee outcome) beats the ~0.43 base rate the review measured. If it does not, that is the
   finding; report it and stop — do not tune thresholds to manufacture a pass.

### Phase 4 — Wire in and prove
- Feed the talent score into `money/scout.py` and the gem screen; regenerate the shortlist.
- Re-run `validate/npv_backtest.py` — the Haaland-vs-Antony £60m gap is the standing sanity anchor; a
  change that *compresses* known-good gaps is a regression, one that widens them is right.
- Write `MODEL_verdict.md`: what the model is, which gates passed/failed with numbers, the honest verdict
  on whether the edge is now *proven* (not just present), and the gem shortlist with the caveats intact.

## Optional feature-enrichment track (only if Phase 3 gate 1 or 4 is marginal)
The review's standing top move is **xT/VAEP from the StatsBomb events already on disk** — it is the one
signal that scores defenders and deep midfielders, the biggest blind-spot class. If your pooled model is
starved of non-attacking signal, build it (`socceraction` is the standard library; events are in
`data/statsbomb/`) and add per-player action-value as a price-blind feature, then re-gate. Treat this as a
sub-track, not the main line — do not let it block shipping the attacking-signal model first.

## What to hand back
`MODEL_verdict.md` (the honest scorecard), `impact/talent.py`, `validate/talent_gate.py`, the regenerated
`data/money/talent_scores.csv`, and a one-paragraph bottom line: **is the edge now proven, and by how much?**
