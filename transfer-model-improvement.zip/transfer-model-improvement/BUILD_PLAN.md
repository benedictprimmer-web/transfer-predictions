# BUILD PLAN — Phase 2 (the model)

*Output: `impact/talent.py` (from the scaffold), a persisted `data/money/talent_scores.csv`, and the
model's own passing `_check()`. The gates come in Phase 3.*

## 1. Architecture: one pooled model

**One model, not per-position.** Perf-rich coverage is too thin to split — FBref features ceiling ~51%,
xG-family ~17%, and defenders/keepers are already sparse. Per-position splits fragment the signal and
overfit. Pool, and let `position` be a feature the model can condition on. Axes stay separate: the talent
model is price-blind; the existing fee model (`money/fees.py`, now leak-fixed) is the price benchmark; the
NPV chain (`money/npv.py`) is the sanity layer. Do not merge them into one model.

## 2. Model choice

Gradient-boosted trees — **HistGradientBoostingRegressor** (sklearn), which the repo already depends on and
uses in `money/fees.py`. It handles missing features natively (important given the coverage table from R2),
captures the age×signal interactions the linear form misses, and is fast enough for walk-forward. Do not
reach for a neural net at this data scale (a few thousand to ~tens of thousands of rows) — it will overfit
and it is not the lever.

Target = the age-residualized forward 2y Δlog(MV) from R1. Features = the price-blind panel from R2.
**The scaffold asserts the feature matrix contains no MV/wage/fee column — keep that assertion.**

## 3. Validation: expanding-window walk-forward (never random)

Mirror the era discipline already correct in `validate/npv_backtest.py`:
- Sort by season. For each target season `s`, train only on player-seasons whose feature season < `s` **and**
  whose target window closed before `s` began. Predict `s`. Never let a fold see its own or later era.
- Suggested anchors (adapt to what R1 yields): train ≤ 2018 · validate 2019–2020 · test 2021–2022 ·
  2023+ diagnostic-only (freshness caveat: data frozen Jan 2025 — see `context/KNOWN_TRAPS.md`).
- Earliest season(s) with insufficient training history are **left unscored and dropped**, not backfilled —
  exactly the pattern the `money/fees.py` fix used (a `MIN_TRAIN_ROWS` floor).

## 4. Outputs

Per player-season, emit:
- `talent_score` — the model's point prediction (a repricing-potential score),
- `talent_lo`, `talent_hi` — an uncertainty band (quantile models or residual bootstrap; a point estimate
  here is a lie, per house rule),
- `talent_pctl` — percentile rank **within season × position** (the rank is what the gem screen consumes),
- `signal_asof` — the latest feature season used, so staleness is visible downstream.

Persist via a `ship()` function to `data/money/talent_scores.csv` (note: `data/` is now tracked in git,
not gitignored as originally written here — the CSV is a build artifact but will appear in `git status`).
Keep the function signature stable so `money/scout.py` can consume it.

## 5. The gem screen, reformulated (this is what proves the model)

The old screen (high efficiency · low usage · young · cheap) did **not** beat base rate (0.44 vs 0.43). Fix
its three flaws:
1. **Within-position** — rank talent inside position, so a low-usage mid is not compared to a poacher.
2. **Age-residual price baseline** — "cheap" means cheap *relative to what a player his age/league normally
   costs*, not cheap absolutely. Use the R1 residual, not a raw MV threshold.
3. **Realized-fee outcome** — backtest the screen against the *fee actually paid at the next transfer
   relative to MV*, and post-transfer performance via `transfer_performance_link_safe`, not the soft
   "MV doubled" label (TM's MV is itself momentum-driven, which is why the base rate was a suspicious 43%).
Then run it on the **selling leagues** (`shots_selling`: Eredivisie/Portugal/Championship/Brazil, 4,144
TM-linked players) where the market is least informed and mispricing should be largest — not only the Big-5
where TM is best-informed and edge is thinnest.

## 6. Wire-in
- `money/scout.py`: replace/augment its candidate ranking with `talent_pctl`; regenerate the shortlist.
- Re-run `validate/npv_backtest.py`: the Haaland-vs-Antony ~£60m gap is the standing anchor. Widening
  known-good gaps = right; compressing them = regression. Report the delta.

## What "done" looks like
`impact/talent.py` implemented and `_check()` green; all four gates in `GATES.md` run with numbers and
bands; `MODEL_verdict.md` states plainly whether the edge is now **proven** (gate 3 and gate 4 both pass) or
merely **present** (separability holds but conversion gates fail) — the same honest distinction the review drew.
