# SCORECARD — the verdict this work comes from

*The July 2026 review graded the estate on five axes (verified, adversarial). Your model targets the two
weakest-leverage axes: Modelling and Usefulness. Full detail is in the repo's `REVIEW_verdict.md`.*

| Axis | Grade | One line |
|---|---|---|
| Quantity of data | C | Deep Big-5 attacker spine, but frozen Jan 2025, position-skewed (0 scoreable keepers), 27% of recent movers have recent shot data |
| Quality of data | C | Hygiene good; fee-model time-leak **fixed this run**; contracts current-state not PIT; estate non-commercial |
| **Usefulness** | C− | Player comparison works for attackers only; **the gem screen does not beat base rate**; rumour demo honestly returns "can't say" on 6/10 |
| Visualisation | B | Dossier investor-presentable; nothing yet shows the thesis; flagship board read "never buy anyone" (0/98 positive NPV) |
| **Modelling** | C | **No trained model** — a hand-built chain with ~24 hand-set constants; the gate-and-band discipline is the best thing here |

## The bottom line you inherit
> **The sauce is real but not yet an edge.** A price-blind talent score is measurable, stable (rho 0.43),
> and diverges from price with signal (rho 0.32→0.41). But every conversion test failed honestly — the gap
> does not yet predict repricing, and the gem screen ties the base rate. The precondition for an edge
> exists; the current formulation doesn't extract it.

Your model is the attempt to extract it. Success = gate 3 (cohort monotonicity) and gate 4 (screen beats
base rate) both pass. Anything less, reported honestly, is still valuable — it tells the owner whether to
keep investing in *modelling* or pivot to *fresher data / xT-VAEP features*.

## What was already fixed in the review run (so you don't redo it)
- **Git initialised** on the whole estate (was version-control-free).
- **Fee-model time-leak closed** — season-grouped expanding-window CV; gate holds (Haaland −30% underpay,
  Antony +160% overpay); honest OOF Spearman 0.79→0.77.
- **HTML-entity name bug root-caused** — `html.unescape()` in the shared normalizer; 55 names recovered
  (Kanté, O'Shea, Eto'o…); crosswalk 6,390→6,433, no regression.
- **Thesis scatter built** (exploratory) — confirmed the caution: the honest gem corner still skews veteran.
