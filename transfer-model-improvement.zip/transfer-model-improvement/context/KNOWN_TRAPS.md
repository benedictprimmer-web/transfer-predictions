# KNOWN TRAPS — load-bearing, not optional

*Each of these has already bitten this project. They are why the review was skeptical and why your gates
are non-negotiable.*

## Silent-corruption history (why `_check()` is not enough)
- A **£425m valuation blow-up** shipped while its module's `_check()` passed (a league-control error).
- A **numpy downgrade silently corrupted the shot cache** — every `_check()` still green.
- Lesson: **gate on out-of-time behaviour and backtests, never on "the check ran."**

## Leaks
- **Random K-fold on time-ordered data** — the exact defect just fixed in `money/fees.py::fit_residuals`
  (was `cross_val_predict(cv=5)` with `season` as a feature, so folds were priced by models trained on
  future seasons). Fixed to season-grouped expanding-window walk-forward. **Do not reintroduce it anywhere.**
- **Contracts are current-state, not point-in-time** — 98% of transfers would see a post-dated expiry.
  Never use `contract_expiration_date`/`contract_years_left` as a feature without freezing as-of the season.
- **TM market value is fee-informed** — so "overpay vs MV" measures against *consensus*, not truth. Keep MV
  strictly as target/benchmark, never as a talent feature (the price-blindness rule).

## Ceilings and dead ends (already gate-tested — do not re-litigate)
- **League strength** failed its predictive gate → descriptive only, never priced. Don't add a league-quality
  step-up adjustment expecting it to lift the predictor; it didn't.
- **Raw age curves** failed the predictor gate → they ship as an NPV decay *shape*, not a point predictor.
  Use `age_multiplier` as a feature and as the target's baseline, not as a standalone talent signal.
- **Usage → WOWY r=+0.077** — per-deal team impact is near-unpredictable. Not your target.
- **xT / possession-value** was built and **failed its NPV gate** (coef≈0) → descriptive scout flag only.
  If you build xT/VAEP as a feature, it may still help the *talent* target even though it failed the *price*
  gate — but prove it with gate 1, don't assume.

## Data-shape gotchas
- **Freshness freeze:** `shots` frozen Jan 2025; 2024-25 is a half-season. 2023+ is diagnostic-only in
  splits. `fbref_perf` 2024-26 xG is on disk and *fresher* — use it, with a partial-season flag on 2026.
- **Crosswalk ceiling 76%** — ~2,000 Understat shooters never resolve to TM; they drop out of every join
  silently (disproportionately non-Latin names). The HTML-entity name bug (`N&#039;Golo Kanté`) was fixed
  July 2026 (crosswalk grew 6,390→6,433); more residual fuzzy-matching is possible but out of scope here.
- **`python3`, not `python`** (plain `python` is not on PATH). The repo is now a **git repo** — commit
  nothing without the owner's say; leave changes in the worktree.
- **`data/` is now tracked in git (changed after this bundle was written)** — the repo was pushed to a
  private GitHub remote and `data/` was un-gitignored so it travels with it. Build artifacts you write
  there (CSVs, the warehouse) will show up in `git status`; they are not committed automatically, but
  don't assume they're invisible to git the way this doc originally claimed.

## Licence (matters if this ever ships)
The estate is **research-grade, not sellable**: StatsBomb (non-commercial), Transfermarkt (DB-rights risk),
FBref/Opta (proprietary), Understat (ambiguous). Your talent *model outputs* are the owner's; the *inputs*
are not redistributable. Don't design anything that assumes a commercial data licence exists.
