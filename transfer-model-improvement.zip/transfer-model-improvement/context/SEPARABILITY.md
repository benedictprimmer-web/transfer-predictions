# SEPARABILITY — the verified empirical starting point

*These numbers were computed and then independently re-verified end-to-end in the July 2026 review (the
re-verification re-ran the analysis script and reproduced every figure). They are your ground floor — you
are not re-deriving them, you are trying to convert them into a model that predicts.*

## What is proven true

1. **The talent score is real signal, not noise.** Season-over-season stability for the same player:
   Spearman **0.43** (composite efficiency+usage), **0.55** (z-efficiency), **0.66** (raw efficiency),
   0.39 (usage share). A noise metric would not persist like this.

2. **Talent and price are related but genuinely divergent** — the precondition for an edge.
   Talent vs contemporaneous TM market value: Spearman **0.32 age-blind**, **0.41 age-adjusted**. That
   sits just below the "useful divergence" zone (0.4–0.7): correlated enough to be about the same players,
   divergent enough that the gap carries information.

3. **The market structurally overpays volume relative to efficiency.** Component correlations with MV:
   actions/volume **0.394** > z-efficiency **0.292** > z-usage **0.139**. A volume-blind, efficiency-weighted
   score therefore diverges from price *by construction* — this is where mispricing should live.

## What is NOT proven (your job to fix or fail honestly)

4. **The gap does not (yet) predict repricing.** Age-adjusted talent-minus-price gap in season S vs MV
   growth to S+1: within every age band Spearman is **0.006–0.066** (essentially zero). The pooled figure
   of **−0.114** is a **Simpson's-paradox artifact**: the age adjustment used (a linear bump that saturates
   at age ≥29) let cheap 30-something veterans dominate the high-gap tail, and TM correctly prices their
   decline. So the pooled negative is *composition*, not information.

   **Implication for you:** (a) residualize the target on a *proper* age(+league) baseline, not a linear
   bump; (b) test conversion *within* position and age strata, never pooled; (c) the honest current verdict
   is **edge present, unproven** — moving it to **proven** is the whole point of the build.

5. **The gem screen did not beat base rate.** Backtest 2015–22: precision **0.44** (11/25) vs base rate
   **0.43** (89/208 — i.e. 43% of *all* young-cheap players double MV anyway). Robust across 5 threshold
   variants. n=25 was too small to detect even a +10pp edge. Reformulate (within-position, age-residual,
   realized-fee outcome, selling leagues) and widen n.

## The ceiling that rules out the wrong target

6. **Usage → WOWY (per-deal team impact) is r=+0.077** [+0.030, +0.125] — real but <1% variance explained.
   Do not target per-deal team impact; it is near-unpredictable at deal level. Forward MV-growth is dense
   and well-posed. This is why the target is forward residualized Δlog(MV).
