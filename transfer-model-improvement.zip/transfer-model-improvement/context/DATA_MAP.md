# DATA MAP — query this, never crawl raw files

Connect (read-only, ~1s): from repo root, `python3 -c "from ingest import warehouse; con =
warehouse.connect(); ..."`. DuckDB, 15 tables, **join on `tm_player_id`** (the hub). `players_master` is
the identity spine (50,149 rows, 0 null tm_player_id). Row counts verified July 2026.

| Table | Rows | Key columns | Range | Notes for the model |
|---|---|---|---|---|
| **players_master** | 50,149 | tm_player_id, name, date_of_birth, position, understat_player_id, fbref_id | DOB 1968–2011 | the hub; age & position source |
| **shots** | 539,971 | league, season, xg, player, player_id (understat), x, y, situation, date | 2014-15 → 2024-25 | Understat Big-5+RFPL; 8,399 shooters; **crosswalk maps 76.1% (6,433 after the entity-bug fix) to tm_player_id** |
| **shots_selling** | 234,800 | league, season, xg, psxg, distance, body_part, tm_player_id, fbref_id | 2018-19 → 2024-25 | Eredivisie/Portugal/Championship/Brazil; 4,144 TM-linked; **the selling-league hunting ground**; 17% null tm |
| **valuations** | 507,815 | player_id, date, market_value_in_eur, current_club_name/id | 2000 → 2026-02 | **the target source**; 445,671 usable rows with ≥2 prior points |
| **transfers_canonical** | 134,147 | transfer_uid, player_id, fee_eur, market_value_eur, from/to_club, season, transfer_date | 1992 → 2026 | fees; 24% null player_id (aggregate rows) |
| **transfer_performance_link_safe** | 91,081 | transfer_uid, player_id, transfer_season, perf_season, fee_eur, goals, xG… | perf ≤2021, transfer ≤2022 | **leak-guarded** (perf_season < transfer_season on all rows); the realized-outcome table |
| **fbref_perf** | 52,951 | tm_player_id, Season_End_Year, Comp, Squad, +215 stat cols incl xG | up to **2026** | **fresher than the "frozen ≤2023" framing** — 2024-25 full xG + partial 2025-26 on disk, unused |
| **fbref_defense** | 14,634 | tm_player_id, season_end_year, tackles/int/blocks p90 | 2018–2025 | defensive actions; price-blind |
| **fbref_niche** | 14,634 | tm_player_id, season_end_year, xa, npxg, psxg (36 cols) | 2018–2025 | turnovers, through-balls, PSxG |
| **contracts** | 50,149 | tm_player_id, contract_expiration_date, contract_years_left, foot, sub_position | expiry to 2035 | **CURRENT-state, not PIT** — do not use expiry as a feature without freezing as-of season |
| **injuries** | 34,561 | tm_player_id, n_spells, career_days_missed, availability, injury_prone | to 2025 | durability features |
| **wages_fifa** | 13,650 | tm_player_id, edition_year, overall, wage_gbp, mv_eur_m | 2017–2021 | **PRICE — do not use as a talent feature** |
| **clubelo_history** | 771,384 | club, country, date, elo | to 2026 | club strength; club-level (no player key) |
| **crosswalk_players** | 6,433 | us_player_id, tm_player_id, us_name, tm_name, method | — | Understat↔TM (grew from 6,390 after the July entity-bug fix) |
| **crosswalk_matches** | 18,917 | understat_game_id, tm_game_id, league, season | — | game-id map (no player key) |

## Coverage facts that shape the model
- **Position skew:** ≥100-career-shots pool = 680 attackers, 476 mids, **215 defenders, 0 keepers**. Shot
  signal covers FW/MF; defenders thin, keepers absent. Decide GK/DEF handling explicitly.
- **Full-feature overlap is thin:** of ~6,400 TM-linked shooters, only ~1,058 have DOB + fresh MV + a wage
  prior simultaneously. Your trainable set is the intersection of price-blind features + a future-dated target.
- **Freshness:** Understat/`shots` frozen at Jan 2025 (2024-25 is a half-season, 24,693 rows vs ~52k).
  `valuations` fresh to 2026-02. **fbref_perf has 2024-26 xG on disk** — the freshest Big-5 signal, unused.
- **Reusable code (do not reinvent):** `impact/usage.py::usage_efficiency`, `impact/aging.py::age_multiplier`,
  `impact/wowy.py::wowy`, `impact/xg_model.py`, `validate/npv_backtest.py` (correct era splits),
  `validate/stage4.py` (the make-or-break gate), `money/fees.py` (leak-fixed price benchmark),
  `money/npv.py`, `money/scout.py`.
