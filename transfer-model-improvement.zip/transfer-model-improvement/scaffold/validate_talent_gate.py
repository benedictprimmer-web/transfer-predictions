"""The four falsifiable gates for the talent model. NEVER loosen a threshold to pass.

DROP AT: validate/talent_gate.py   (run: python3 -m validate.talent_gate)

Each gate returns a dict {name, passed, number, ci, n, note}. A FAIL is a finding to report, not a bug to
hide. A green _check() elsewhere proves nothing about correctness — THESE gates do. See GATES.md for the
rationale and the exact pass conditions.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


def _boot_ci(stat_fn, *arrays, n_boot: int = 1000, seed: int = 0):
    """Bootstrap CI for a statistic over paired arrays. Returns (point, lo, hi)."""
    rng = np.random.default_rng(seed)
    a = [np.asarray(x) for x in arrays]
    n = len(a[0])
    point = stat_fn(*a)
    draws = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        draws.append(stat_fn(*[x[idx] for x in a]))
    lo, hi = np.percentile(draws, [2.5, 97.5])
    return float(point), float(lo), float(hi)


def gate1_beats_age_baseline(test_df: pd.DataFrame, target: str,
                             talent_pred: str, age_pred: str) -> dict:
    """Talent model must beat an age(+league)-only baseline out-of-time, CI on the lift excludes 0.
    test_df must be HELD-OUT (test-era) rows only. talent_pred/age_pred are prediction columns."""
    from scipy.stats import spearmanr
    y = test_df[target].to_numpy()
    t = test_df[talent_pred].to_numpy()
    a = test_df[age_pred].to_numpy()
    def lift(y_, t_, a_):
        return spearmanr(t_, y_).statistic - spearmanr(a_, y_).statistic
    point, lo, hi = _boot_ci(lift, y, t, a)
    return {"name": "gate1_beats_age_baseline", "passed": lo > 0,
            "number": point, "ci": (lo, hi), "n": len(y),
            "note": "talent vs age-only Spearman lift; PASS iff CI excludes 0"}


def gate2_haaland_antony(price_gap_fn) -> dict:
    """Feeding the talent score into the price gap must keep Haaland underpay / Antony overpay.
    price_gap_fn(name, to_club) -> signed gap (negative = underpay, positive = overpay)."""
    haa = price_gap_fn("Haaland", "Manchester City")
    ant = price_gap_fn("Antony", "Manchester United")
    passed = (haa < 0) and (ant > 0)
    return {"name": "gate2_haaland_antony", "passed": passed,
            "number": {"haaland": haa, "antony": ant}, "ci": None, "n": 2,
            "note": "PASS iff Haaland<0 (underpay) and Antony>0 (overpay); no sign flip"}


def gate3_cohort_monotonicity(test_df: pd.DataFrame, gap_col: str, realized_col: str,
                              n_deciles: int = 10) -> dict:
    """Bucket held-out players by talent-minus-price gap; realized forward growth/fee-premium must rise
    with the decile. PASS iff top-minus-bottom spread CI excludes 0 (and trend is ~monotone).
    THIS is the gate the review's persistence test FAILED — passing it is the bar for 'edge proven'."""
    d = test_df[[gap_col, realized_col]].dropna().copy()
    d["decile"] = pd.qcut(d[gap_col].rank(method="first"), n_deciles, labels=False)
    med = d.groupby("decile")[realized_col].median()
    top = d[d["decile"] == n_deciles - 1][realized_col].to_numpy()
    bot = d[d["decile"] == 0][realized_col].to_numpy()
    def diff(t_, b_):  # unpaired; resample each side
        return np.median(t_) - np.median(b_)
    rng = np.random.default_rng(0)
    draws = [diff(rng.choice(top, len(top)), rng.choice(bot, len(bot))) for _ in range(1000)]
    lo, hi = np.percentile(draws, [2.5, 97.5])
    # monotonic-ish: fraction of upward steps
    steps = np.diff(med.to_numpy())
    mono = float((steps > 0).mean())
    return {"name": "gate3_cohort_monotonicity", "passed": lo > 0 and mono >= 0.6,
            "number": {"top_minus_bottom": float(np.median(top) - np.median(bot)),
                       "upward_step_frac": mono}, "ci": (float(lo), float(hi)), "n": len(d),
            "note": "PASS iff top-bottom spread CI excludes 0 AND >=60% deciles step up"}


def gate4_screen_beats_base_rate(screen_hits: int, screen_n: int,
                                 base_hits: int, base_n: int) -> dict:
    """Reformulated gem screen precision must beat the base rate (all comparable players), CI on the gap
    excludes 0. The review's old screen scored 0.44 vs a 0.43 base rate — indistinguishable. Report n:
    too-small n cannot detect a real edge (state the power limit honestly)."""
    p_screen = screen_hits / screen_n if screen_n else float("nan")
    p_base = base_hits / base_n if base_n else float("nan")
    # bootstrap the difference in proportions
    rng = np.random.default_rng(0)
    s = np.r_[np.ones(screen_hits), np.zeros(screen_n - screen_hits)]
    b = np.r_[np.ones(base_hits), np.zeros(base_n - base_hits)]
    draws = [rng.choice(s, screen_n).mean() - rng.choice(b, base_n).mean() for _ in range(2000)]
    lo, hi = np.percentile(draws, [2.5, 97.5])
    return {"name": "gate4_screen_beats_base_rate", "passed": lo > 0,
            "number": {"precision": p_screen, "base_rate": p_base}, "ci": (float(lo), float(hi)),
            "n": screen_n, "note": "PASS iff (screen - base) CI excludes 0; report n / power"}


def report(gates: list[dict]) -> None:
    print("\n=== TALENT-MODEL GATES ===")
    for g in gates:
        flag = "PASS" if g["passed"] else "FAIL"
        print(f"[{flag}] {g['name']}: {g['number']}  ci={g['ci']}  n={g['n']}")
    verdict = ("edge PROVEN" if all(g["passed"] for g in gates if g["name"] in
               ("gate3_cohort_monotonicity", "gate4_screen_beats_base_rate"))
               else "edge PRESENT BUT UNPROVEN (conversion gate failed)")
    print(f"VERDICT: {verdict}")


def _check() -> None:
    """Offline: prove the gate math runs and correctly separates a planted signal from noise."""
    rng = np.random.default_rng(1)
    n = 600
    # planted: talent_pred correlates with target, age_pred does not
    y = rng.normal(0, 1, n)
    df = pd.DataFrame({"y": y, "talent": y * 0.4 + rng.normal(0, 1, n),
                       "age": rng.normal(0, 1, n),
                       "gap": y * 0.3 + rng.normal(0, 1, n), "realized": y})
    g1 = gate1_beats_age_baseline(df, "y", "talent", "age")
    g3 = gate3_cohort_monotonicity(df, "gap", "realized")
    g4 = gate4_screen_beats_base_rate(30, 50, 43, 100)   # 0.60 vs 0.43
    assert g1["passed"], "planted signal should beat age baseline"
    assert g3["passed"], "planted monotone cohort should pass"
    assert g4["passed"], "0.60 vs 0.43 with these n should pass"
    # negative control: pure noise must FAIL gate 1
    dfn = pd.DataFrame({"y": rng.normal(0, 1, n), "talent": rng.normal(0, 1, n),
                        "age": rng.normal(0, 1, n)})
    assert not gate1_beats_age_baseline(dfn, "y", "talent", "age")["passed"], "noise must fail gate 1"
    print("ok")


if __name__ == "__main__":
    _check()
