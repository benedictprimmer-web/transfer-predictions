"""Price-blind talent model — score a player's on-pitch quality independent of price.

DROP AT: impact/talent.py  (run: python3 -m impact.talent  → offline _check;  build → real fit)

The commercial thesis: edge = players whose on-pitch quality ranks far above what their price implies.
Market value / wage / fee are PARALLEL CONTEXT, never inputs here. This module scores quality from
on-pitch signal alone; price enters only as the TARGET (forward MV growth) and the benchmark gap.

Target      : age(+league)-residualized forward 2-year Δlog(market value)   [see RESEARCH_PLAN R1]
Model       : one pooled HistGradientBoostingRegressor, expanding-window walk-forward (NEVER random CV)
Price-blind : enforced by _assert_price_blind() at fit time — do not remove that assertion.

Everything marked TODO is yours to implement. The scaffolding (price-blindness guard, walk-forward
skeleton, _check) is deliberately complete so you cannot accidentally skip the guardrails.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

# Columns that would leak price into a "price-blind" model. The guard rejects any feature whose name
# contains one of these tokens. Extend if you add sources — err toward over-blocking.
_PRICE_TOKENS = ("market_value", "mv_", "_mv", "value_eur", "wage", "salary", "fee", "overpay", "price")

# Price-blind feature columns the model may use. Fill from RESEARCH_PLAN R2 (usage share, npxG efficiency,
# own-xG geometry, minutes-at-level, pooled WOWY, turnovers, defensive actions, age & age^2, position,
# availability, [optional] xT/VAEP). Age is allowed as a FEATURE and is also the target's baseline.
FEATURES: list[str] = [
    # "usage_share", "npxg_eff", "own_xg_mean", "minutes_at_level", "wowy_pooled",
    # "turnovers_p90", "def_actions_p90", "age", "age_sq", "position_code", "availability",
]  # TODO: populate

MIN_TRAIN_ROWS = 200          # a target-season needs at least this much prior history to be scored
TARGET = "fwd_mv_resid"        # age(+league)-residualized forward 2y Δlog(MV)  [built in build_panel]


def _assert_price_blind(X: pd.DataFrame) -> None:
    """Fail loudly if any feature smells of price. This assertion is the whole point — keep it."""
    bad = [c for c in X.columns for t in _PRICE_TOKENS if t in c.lower()]
    if bad:
        raise AssertionError(f"price leaked into talent features: {sorted(set(bad))}")


def build_panel(con) -> pd.DataFrame:
    """One row per player-season: price-blind FEATURES + the future-dated TARGET + [season, position].

    Reuse existing code — do NOT reinvent:
      impact.usage.usage_efficiency  → usage_share, efficiency (penalties/OGs already excluded)
      impact.aging.age_multiplier    → age-curve position (a feature AND the target's baseline)
      impact.wowy.wowy               → pooled per-player-season team on/off (thin; optional)
    TARGET: from `valuations`, Δlog(MV) anchor→anchor+2y, residualized on log(MV) ~ age+age^2+league.
    Enforce strict future-dating: the target window must start AFTER the feature season ends.
    """
    raise NotImplementedError("TODO: build the price-blind panel per RESEARCH_PLAN R1+R2")


def fit_walk_forward(panel: pd.DataFrame):
    """Expanding-window walk-forward. For each target season s (ascending), train on rows whose feature
    season < s AND whose target window closed before s began; predict s. Earliest thin seasons are left
    UNSCORED and dropped (MIN_TRAIN_ROWS floor) — never backfilled. Returns panel + talent_score/lo/hi.

    This is the ONLY validation scheme. Random K-fold is the leak this project just fixed elsewhere.
    """
    from sklearn.ensemble import HistGradientBoostingRegressor  # already a repo dependency

    d = panel.dropna(subset=[TARGET]).sort_values("season").copy()
    X_all = d[FEATURES]
    _assert_price_blind(X_all)

    preds = pd.Series(index=d.index, dtype=float)
    for s in sorted(d["season"].unique()):
        train = d["season"] < s                      # TODO: also enforce target-window-closed < s
        if train.sum() < MIN_TRAIN_ROWS:
            continue                                  # unscored, dropped — disclosed, not backfilled
        m = HistGradientBoostingRegressor()          # TODO: tune; add quantile models for lo/hi band
        m.fit(d.loc[train, FEATURES], d.loc[train, TARGET])
        preds.loc[d["season"] == s] = m.predict(d.loc[d["season"] == s, FEATURES])

    out = d.assign(talent_score=preds).dropna(subset=["talent_score"])
    # TODO: talent_lo / talent_hi via quantile regressors or residual bootstrap (a point estimate is a lie).
    # TODO: talent_pctl = rank within season x position; signal_asof = latest feature season used.
    return out


def ship(con, out_path: str = "data/money/talent_scores.csv") -> pd.DataFrame:
    """Fit on real data and persist scores. NOTE: data/ is now tracked in git (no longer gitignored) —
    this is still a build artifact, but it will show up in `git status`, not disappear silently."""
    scored = fit_walk_forward(build_panel(con))
    scored.to_csv(out_path, index=False)
    print(f"wrote {len(scored):,} talent scores -> {out_path}")
    return scored


def _check() -> None:
    """Offline synthetic self-check. Proves the code RUNS and the guardrails BITE — it does NOT prove the
    model is correct (that is what validate/talent_gate.py is for). Gate on behaviour, never on this."""
    rng = np.random.default_rng(0)
    n = 800
    panel = pd.DataFrame({
        "season": rng.integers(2015, 2023, n),
        "position": rng.choice(["FW", "MF", "DF"], n),
        "feat_a": rng.normal(0, 1, n),
        "feat_b": rng.normal(0, 1, n),
        TARGET: rng.normal(0, 1, n),
    })
    # local override of FEATURES for the synthetic check only
    global FEATURES
    saved, FEATURES = FEATURES, ["feat_a", "feat_b"]
    try:
        scored = fit_walk_forward(panel)
        assert "talent_score" in scored and scored["talent_score"].notna().all()
        # the price-blindness guard must actually fire:
        leaked = False
        try:
            _assert_price_blind(pd.DataFrame({"market_value_eur": [1.0]}))
        except AssertionError:
            leaked = True
        assert leaked, "price-blindness guard failed to fire"
    finally:
        FEATURES = saved
    print("ok")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "build":
        from ingest import warehouse
        ship(warehouse.connect())
    else:
        _check()
