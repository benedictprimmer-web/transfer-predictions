# GATES — the contract (never loosened)

*Four falsifiable gates. Each has a hard threshold. A model that fails a gate has produced a **finding**,
not a failure of your run — report it plainly and stop. Loosening a threshold to pass is the one
unforgivable move on this project. `scaffold/validate_talent_gate.py` implements these as runnable asserts;
wire your model output in.*

## Gate 1 — Beats an age-only baseline, out-of-time
**Why:** a talent model that is secretly an age curve is worthless — the market already prices age.
**Test:** on held-out (test-era) player-seasons, compare the talent model's prediction of the residualized
forward-MV target against a baseline that uses **age (and league) only**. The talent model's out-of-time R²
(or Spearman) must exceed the age-only baseline's by a margin whose bootstrap CI **excludes zero**.
**Pass:** talent model beats age-only baseline, CI on the lift excludes 0. **Fail:** it doesn't — then the
price-blind features add nothing beyond age, and you say so.

## Gate 2 — Haaland-underpay / Antony-overpay sanity
**Why:** the standing sanity anchor for the whole valuation stack; if the model disagrees with the entire
football world here, the model is broken, not brave.
**Test:** feed the talent score into the price-gap computation and confirm the direction holds: **Haaland →
Man City reads underpay, Antony → Man Utd reads overpay.** (The leak-fixed `money/fees.py` currently gives
Haaland −30% / Antony +160% — your talent-informed gap must not flip either sign.)
**Pass:** both signs correct, substantial magnitude. **Fail:** a sign flips → stop and report.

## Gate 3 — Decile forward-MV cohort monotonicity
**Why:** the direct test of the thesis — does a bigger talent-minus-price gap actually predict repricing?
**Test:** on held-out seasons, bucket players into deciles by talent-minus-price gap. Realized forward-MV
growth (or realized-fee premium at next transfer) must **rise with the decile** — a monotone, or near-monotone
with a clearly positive top-minus-bottom spread whose CI excludes zero. This is the gate the review's
persistence test **failed** (within-band rho 0.006–0.066); passing it is the bar for "edge proven."
**Pass:** monotone increasing, top−bottom spread CI excludes 0. **Fail:** flat or non-monotone → the edge is
present but unproven; report exactly that, do not tune the buckets.

## Gate 4 — Gem screen beats base rate
**Why:** the applied proof. The old screen scored 0.44 precision against a 0.43 base rate — indistinguishable
from random.
**Test:** run the reformulated screen (within-position · age-residual baseline · realized-fee outcome, per
`BUILD_PLAN.md` §5) as-of each historical season, held out. Precision must **beat the base rate** (the
fraction of *all* comparable players who hit) by a margin whose CI excludes zero. Report n — the review's
n=25 was too small to detect even a +10pp edge, so widen the screened set or state the power limit honestly.
**Pass:** precision > base rate, CI on the gap excludes 0, n adequate. **Fail:** no better than random →
that is the headline finding; report it and stop.

## The meta-gate
A green `_check()` is **not** a pass. `_check()` proves the code runs on synthetic data; the four gates above
prove the *result is correct* on real, out-of-time data. This project has shipped a £425m blow-up and a
corrupted cache with every `_check()` green. **Gate on behaviour and backtests, always.**

## Reporting
`MODEL_verdict.md` states, per gate: PASS/FAIL, the number, the CI, and n. Then one honest sentence:
**edge PROVEN** (gates 3 and 4 both pass) / **edge PRESENT BUT UNPROVEN** (separability holds, conversion
gates fail) / **no edge** (separability itself doesn't survive out-of-time). No salesmanship.
