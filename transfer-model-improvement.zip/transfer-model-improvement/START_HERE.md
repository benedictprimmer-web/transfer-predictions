# START HERE — Model-improvement handoff for GPT 5.6

You are being handed a **verified review** of a football-transfer valuation system and a mandate to
**improve its model**. This bundle is self-contained. Read it in this order, then execute `PROMPT.md`.

## What this is

The system (`~/Transfer Predictions`, Python + read-only DuckDB warehouse) prices transfers today with
a *hand-built scoring chain* — there is **no trained model**. A 70-agent skeptical review (July 2026)
established, with adversarial verification, exactly where it stands and what the single highest-value
model improvement is:

> **Build the price-blind talent model.** Score a player's on-pitch quality *independent of his price*,
> so the commercial edge — players whose quality ranks far above their price — can finally be measured
> and *proven*, not asserted.

The review found the precondition for that edge is real (talent and price diverge with signal) but that
every conversion test failed **honestly** — the current formulation does not predict repricing. Your job
is to build the model that does, or to fail it honestly against a gate. **Never loosen a gate.**

## Read in this order

1. `context/SCORECARD.md` — the verdict: why this work matters, in one page.
2. `context/SEPARABILITY.md` — the empirical starting point (the verified numbers you build on).
3. `context/DATA_MAP.md` — the warehouse schema, coverage, join keys. **Query this; never crawl raw files.**
4. `context/KNOWN_TRAPS.md` — the leaks, ceilings, and freezes that will bite you. Load-bearing.
5. `RESEARCH_PLAN.md` — Phase 1: what to establish before you write model code.
6. `BUILD_PLAN.md` — Phase 2: the concrete model design, feature set, splits.
7. `GATES.md` — the falsifiable gates every deliverable must pass. This is the contract.
8. `PROMPT.md` — **your actual brief.** Execute this.

## Scaffolds (drop into the repo, then implement)

- `scaffold/impact_talent.py` → copy to `impact/talent.py` — the model module skeleton (price-blindness
  assertion, expanding-window loop, `_check()` already wired; the model itself is your TODO).
- `scaffold/validate_talent_gate.py` → copy to `validate/talent_gate.py` — the four gates as runnable
  asserts; wire your model output in.

## The one rule above all others

A green self-check is **not** a correct result. This project has shipped a £425m valuation blow-up and a
numpy-corrupted cache while every `_check()` passed. **Gate on behaviour and out-of-time backtests.** If a
result fails its gate, say so plainly and stop — do not fudge, do not backfill, do not loosen the threshold.
